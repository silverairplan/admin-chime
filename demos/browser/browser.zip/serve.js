const { serve } = require('./server.js');

serve();